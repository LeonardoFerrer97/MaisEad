﻿using System;
namespace MaisEad.Properties
{
    public class ConnectionString
    {
        public static string DbConnection { get; set; }
    }
}
