﻿using System;
namespace MaisEad.Dto.Dto
{
    public class TipoCursoDto
    {
        public int IdTipo{ get; set; }
        public string NomeTipo{ get; set; }
    }
}
