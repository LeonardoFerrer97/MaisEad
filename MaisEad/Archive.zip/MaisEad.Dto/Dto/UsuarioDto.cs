﻿using System;
using System.Collections.Generic;

namespace MaisEad.Dto.Dto
{
    public class UsuarioDto
    {

        public int Id { get; set; }
        public string Email { get; set; }
    }
}
