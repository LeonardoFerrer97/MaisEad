﻿using System;

namespace MaisEad.Repository
{
    public class Class1
    {
    }
}
