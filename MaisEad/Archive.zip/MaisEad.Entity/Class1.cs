﻿using System;

namespace MaisEad.Entity
{
    public class Class1
    {
    }
}
