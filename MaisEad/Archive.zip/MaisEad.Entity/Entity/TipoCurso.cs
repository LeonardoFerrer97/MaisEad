﻿using System;
namespace MaisEad.Entity.Entity
{
    public class TipoCurso
    {
        public int IdTipo{ get; set; }
        public string NomeTipo{ get; set; }
    }
}
