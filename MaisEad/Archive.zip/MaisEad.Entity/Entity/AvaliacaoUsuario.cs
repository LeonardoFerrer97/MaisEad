﻿using System;
namespace MaisEad.Entity.Entity
{
    public class AvaliacaoUsuario
    {

        public int AvaliacaoUsuarioId { get; set; }
        public int CursoIdAvaliacao{ get; set; }
        public int Nota { get; set; }
    }
}
