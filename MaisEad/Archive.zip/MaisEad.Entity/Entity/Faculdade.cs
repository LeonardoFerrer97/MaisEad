﻿using System;
namespace MaisEad.Entity.Entity
{
    public class Faculdade
    {
        public int FaculId { get; set; }
        public string NomeFaculdade { get; set; }
        public string Endereco { get; set; }
        public int NotaMecFaculdade { get; set; }
    }
}
