﻿using System;

namespace MaisEad.Interface.Repository
{
    public class Class1
    {
    }
}
