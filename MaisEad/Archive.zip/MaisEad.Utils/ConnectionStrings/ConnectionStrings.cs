﻿using System;
namespace MaisEad.Utils.ConnectionStrings
{
    public class ConnectionStrings
    {
        public string DbConnection { get; set; }
    }
}
